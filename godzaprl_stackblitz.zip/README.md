# GodzAprl.Co - StackBlitz-ready Next.js + Tailwind Starter

This project is a starter for a black/red luxury/motivational brand site with an online store (mock products).

## To run locally (if you have Node):
1. `npm install`
2. `npm run dev`
3. open http://localhost:3000

## To deploy from Chromebook (quick):
- Upload this project to StackBlitz or push to GitHub and import to Vercel.
- See the step-by-step deployment guide provided in the chat response.

