import Link from 'next/link'
import { useCart } from '../lib/cartContext'
import { useState } from 'react'

export default function Header(){
  const { cart } = useCart()
  const [open, setOpen] = useState(false)
  return (
    <header className="bg-black/60 backdrop-blur-sm border-b border-gray-800">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-6">
          <Link href="/"><a className="text-2xl font-display font-bold text-white glow">GodzAprl.Co</a></Link>
          <nav className="hidden md:flex gap-4">
            <Link href="/products"><a className="px-3 py-2 rounded hover:bg-white/5">Products</a></Link>
            <Link href="/vendors/create"><a className="px-3 py-2 rounded hover:bg-white/5">Become a Vendor</a></Link>
            <Link href="/about"><a className="px-3 py-2 rounded hover:bg-white/5">About</a></Link>
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <Link href="/search"><a className="hidden sm:inline px-3 py-2 rounded hover:bg-white/5">Search</a></Link>
          <Link href="/cart"><a className="relative px-3 py-2">
            Cart
            <span className="ml-2 inline-flex items-center justify-center rounded-full bg-brand-500 px-2 py-1 text-xs text-white">{cart.length}</span>
          </a></Link>
          <button className="md:hidden" onClick={()=>setOpen(!open)}>Menu</button>
        </div>
      </div>
      {open && (
        <div className="md:hidden bg-black/80 border-t border-gray-800">
          <div className="p-4">
            <Link href="/products"><a className="block py-2">Products</a></Link>
            <Link href="/vendors/create"><a className="block py-2">Become a Vendor</a></Link>
            <Link href="/login"><a className="block py-2">Sign In</a></Link>
          </div>
        </div>
      )}
    </header>
  )
}
