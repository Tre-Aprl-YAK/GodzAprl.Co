import Link from 'next/link'
export default function ProductCard({ product }){
  return (
    <div className="border border-gray-800 rounded overflow-hidden shadow-sm hover:shadow-md transition">
      <img src={product.image} className="w-full h-48 object-cover" alt={product.name} />
      <div className="p-4 bg-black">
        <h3 className="font-semibold text-white">{product.name}</h3>
        <p className="mt-2 text-gray-400">${product.price.toFixed(2)}</p>
        <div className="mt-4 flex gap-2">
          <Link href={`/product/${product.id}`}><a className="px-3 py-2 border border-gray-700 rounded">View</a></Link>
        </div>
      </div>
    </div>
  )
}
