export default function handler(req, res) {
  const id = req.query.id
  const data = {
    p1: { id:'p1', name: 'Divine Hoodie', price:69.99, image:'/assets/p1.jpg', description:'Premium heavyweight hoodie' },
    p2: { id:'p2', name: 'Motiv Tee', price:29.99, image:'/assets/p2.jpg', description:'Soft cotton tee' },
    p3: { id:'p3', name: 'Crown Snapback', price:24.99, image:'/assets/p3.jpg', description:'Embroidered snapback' }
  }
  if (data[id]) return res.status(200).json(data[id])
  return res.status(404).json({ message: 'Not found' })
}
