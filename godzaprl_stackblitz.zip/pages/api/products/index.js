export default function handler(req, res) {
  const products = [
    { id:'p1', name: 'Divine Hoodie', price:69.99, image:'/assets/p1.jpg', description:'Premium heavyweight hoodie' },
    { id:'p2', name: 'Motiv Tee', price:29.99, image:'/assets/p2.jpg', description:'Soft cotton tee' },
    { id:'p3', name: 'Crown Snapback', price:24.99, image:'/assets/p3.jpg', description:'Embroidered snapback' }
  ]
  res.status(200).json(products)
}
