import Head from 'next/head'
import Header from '../components/Header'
import ProductCard from '../components/ProductCard'
import Link from 'next/link'

export default function Home({ products }) {
  return (
    <>
      <Head>
        <title>GodzAprl.Co — Divine Streetwear</title>
        <meta name="description" content="GodzAprl.Co — streetwear with a divine, motivating edge." />
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&family=Playfair+Display:wght@700&display=swap" rel="stylesheet" />
      </Head>
      <Header />
      <main>
        <section className="bg-gradient-to-b from-black to-[#080808] text-white py-12">
          <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center gap-8">
            <div className="md:w-1/2">
              <h1 className="text-5xl font-display font-extrabold glow">Ascend. Conquer. Inspire.</h1>
              <p className="mt-4 text-lg text-gray-300">Luxury streetwear with a divine, motivational edge. Limited drops — built for winners.</p>
              <Link href="/products"><a className="inline-block mt-6 bg-brand-500 px-6 py-3 rounded text-white font-semibold">Shop Now</a></Link>
            </div>
            <div className="md:w-1/2">
              <img src="/assets/hero.jpg" alt="hero" className="rounded shadow-lg w-full" />
            </div>
          </div>
        </section>

        <section className="py-12">
          <div className="max-w-7xl mx-auto px-4">
            <h2 className="text-2xl font-bold mb-6">Featured products</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {products.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        </section>
      </main>
      <footer className="bg-black py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-sm text-gray-500">© {new Date().getFullYear()} GodzAprl.Co — All rights reserved.</div>
      </footer>
    </>
  )
}

export async function getStaticProps(){
  const res = await fetch('http://localhost:3000/api/products').catch(()=>null)
  let products = []
  if (res && res.ok) products = await res.json()
  if (!products || products.length===0) {
    products = [
      { id:'p1', name: 'Divine Hoodie', price:69.99, image:'/assets/p1.jpg', description:'Premium heavyweight hoodie' },
      { id:'p2', name: 'Motiv Tee', price:29.99, image:'/assets/p2.jpg', description:'Soft cotton tee' },
      { id:'p3', name: 'Crown Snapback', price:24.99, image:'/assets/p3.jpg', description:'Embroidered snapback' }
    ]
  }
  return { props: { products } }
}
