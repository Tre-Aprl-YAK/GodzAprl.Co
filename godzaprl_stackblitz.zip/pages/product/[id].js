import Header from '../../components/Header'
import { useCart } from '../../lib/cartContext'

export default function ProductPage({ product }){
  const { add } = useCart()
  if (!product) return <div>Product not found</div>
  return (
    <>
      <Header />
      <div className="max-w-5xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 gap-8">
          <img src={product.image} className="w-full h-96 object-cover rounded" />
          <div>
            <h1 className="text-3xl font-bold">{product.name}</h1>
            <p className="mt-4 text-gray-300">{product.description}</p>
            <div className="mt-6">
              <span className="text-2xl font-semibold">${product.price.toFixed(2)}</span>
            </div>
            <div className="mt-6">
              <button onClick={()=>add(product)} className="bg-brand-500 text-white px-5 py-3 rounded">Add to cart</button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export async function getServerSideProps(context){
  const { id } = context.params
  const res = await fetch(`http://localhost:3000/api/products/${id}`).catch(()=>null)
  if (!res || !res.ok) {
    return { props: { product: { id:'p1', name:'Divine Hoodie', price:69.99, image:'/assets/p1.jpg', description:'Premium heavyweight hoodie' } } }
  }
  const product = await res.json()
  return { props: { product } }
}
