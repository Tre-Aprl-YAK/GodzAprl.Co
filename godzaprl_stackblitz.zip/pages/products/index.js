import Header from '../../components/Header'
import ProductCard from '../../components/ProductCard'

export default function Products({ products }) {
  return (
    <>
      <Header />
      <div className="max-w-7xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-6">All Products</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {products.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      </div>
    </>
  )
}

export async function getStaticProps(){
  const res = await fetch('http://localhost:3000/api/products').catch(()=>null)
  const products = res && res.ok ? await res.json() : []
  return { props: { products } }
}
